package com.company;

public class Temptation extends Action {
    public void evaluateChoice(Character C)
    {
        boolean choice = false;
        if(choice == true)
        {
            doSin(C);
        }
        else
        {
            doResistence(C);
        }

    }
    public void doSin(Character C)
    {

    }
    public void doResistence(Character C)
    {

    }
}
