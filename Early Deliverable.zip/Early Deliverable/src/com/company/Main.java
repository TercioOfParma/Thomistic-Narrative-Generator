package com.company;

public class Main {

    public static void main(String[] args)
    {
	    Character C = new Character();
	    System.out.println(String.valueOf(C.getLengthOfActions()));
    }
}
