package com.company;

public class ActualGrace extends Action
{
    public void evaluateChoice(Character C)
    {
        boolean choice = false;
        if(choice == true)
        {
            concomitantAction(C);
        }
        else
        {
            return;
        }
    }
    public void concomitantAction(Character C)
    {

    }
}
